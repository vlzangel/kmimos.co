function animateButton() {		
	document.getElementById("linkup").className += " animate";
}
