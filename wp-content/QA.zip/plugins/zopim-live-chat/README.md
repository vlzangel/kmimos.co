# zendesk-chat-wordpress

## Releasing new versions of the plugin to wordpress.org

If you are a developer looking to release a new version of the plugin

See: [This guide](https://zendesk.atlassian.net/wiki/display/ENG/Publishing+new+versions+of+plugins+to+Wordpress.org)
