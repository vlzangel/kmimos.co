<?php
/**
 * 
 * @file extensions.php A brief description of our extensions.
 * 
 * */

// Security Check
if( !defined( 'ABSPATH' ) ) die();
global $FileManager;
?>
<div class='fm-extensions'>
	
	<h2>Themepack</h2>
	<p>
		<h4><a href='http://giribaz.com/file-manager-themepack/'>Themepack</a></h4>
		<ul>
			<li>50 Different Themes</li>
			<li>Supports backend and frontend</li>
			<li>2 Series of themes</li>
			<li>Super easy to install</li>
		</ul>
	</p>
	<br/>
	<a class='fm-call-toaction' href='http://giribaz.com/file-manager-themepack/'>Get it now!</a>
	<br/>
	<br/>
</div>
