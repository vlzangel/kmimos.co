<?php
/**
 *
 * @file sales.php Donate links will go here
 *
 * */

// Security Check
if( !defined('ABSPATH') ) die();
global $FileManager;
?>

<div class='fm-donate'>
	<a href='http://www.giribaz.com'>
		<img style='width:100%;' src='<?php echo plugin_dir_url(__FILE__) . '..' . '/' . '..' . '/' . 'img' . '/' . 'new_year_sales_60_percent_off.png'; ?>' >
	</a>
</div>
