<?php

header( 'Content-type: javascript/text; charset=UTF-8' );
$base_path = chdir('..')
?>

UTILITY = {
	
	'baseURL': '<?php echo 'some_url'; ?>',
	
}
