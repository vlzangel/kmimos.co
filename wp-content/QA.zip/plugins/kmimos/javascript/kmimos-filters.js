jQuery.noConflict(); 
jQuery(document).ready(document).ready(function() {
	jQuery("#contenedor-filtros").accordion();
/*	jQuery(".selector-filtro").css({ "margin-top":"2px" });
	jQuery(".selector-filtro").parent().css({ "padding":"8px" });
	jQuery(".selector-filtro > div.ui-flipswitch").css({ "width":"74px" });*/
	jQuery(".filter_css > h2.widgettitle").css({ "display":"block" });
});
