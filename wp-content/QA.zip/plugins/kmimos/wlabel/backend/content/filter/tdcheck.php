<div class="filter">
    <div class="type tdshow" data-type="tdcheck">
        <div class="day line">
            <label>Días</label>
            <input type="checkbox" name="day" value="yes"/>
        </div>

        <div class="month line">
            <label>Mes</label>
            <input type="checkbox" name="month" value="yes" checked/>
        </div>

        <div class="year line">
            <label>Año</label>
            <input type="checkbox" name="year" value="yes" checked/>
        </div>

        <div class="total line">
            <label>Total</label>
            <input type="checkbox" name="total" value="yes" checked/>
        </div>
    </div>
</div>