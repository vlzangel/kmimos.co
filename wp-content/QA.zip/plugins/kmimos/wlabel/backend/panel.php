<?php
    $_wlabel_user->LogOut_Html();
?>
<div class="section">
    <?php
        include_once(dirname(__FILE__).'/content/menu.php');
        include_once(dirname(__FILE__).'/content/modules.php');
    ?>
</div>


